package testCases;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.apache.commons.io.FileUtils;
import org.junit.*;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import pages.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static junit.framework.TestCase.fail;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SanityRun {
    private static WebDriver driver;
     LoginPage login = new LoginPage(driver); // create object.Than it's go to constructor in LoginPage
     HomePage home= new HomePage(driver); // create object.Than it's go to constructor in HomePage
     BoysShirtsPage myShort=new BoysShirtsPage(driver);
     PaymentPage payment= new PaymentPage(driver);
     // 3 follow rows need to report
     private static ExtentReports extentReports = new ExtentReports();
     private static ExtentSparkReporter sparkReporter = new ExtentSparkReporter(Constants.PATH_REPORTS);
     String currentTime = String.valueOf(System.currentTimeMillis());//Need to display screen shot's time


    @BeforeClass
    public static void BeforeClass() throws ParserConfigurationException, IOException, SAXException {
        extentReports.attachReporter(sparkReporter); // connect report to path
        sparkReporter.config().setReportName("Next site report");//name of report
        //path of chrome driver file from Constants
        System.setProperty("webdriver.chrome.driver", Constants.CHROME_DRIVER_LOCATION);
        ChromeOptions options = new ChromeOptions();
        driver=new ChromeDriver(options);
        driver.manage().window().maximize();//open in full window
        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS); //waiting() function need it
        //path of URL of NEXT site from config.xml
        driver.get(getData("URL_NEXT"));
    }

    //login with username and password
    @Test
    public void a_loginTest() throws ParserConfigurationException, IOException, SAXException, InterruptedException {
        ExtentTest test1 = extentReports.createTest("test1- screen of login");// title in report
        test1.log(Status.INFO, "Login page");//information that will appear in the detail's column report
        Thread.sleep(1000);
        LoginPage login = new LoginPage(driver); //create object.Than it's go to constructor in LoginPage
        login.clickAccountBtn();                //Go to LoginPage and ckick on "My Account" link

        //Verify That you are in the Login page

        String expectedTitle= driver.getTitle();
        if(Constants.TITLE_LOGIN.equals(expectedTitle))
            test1.pass("Test 1.1 pass. Your are in the right login page!");
        else
            test1.fail("Test 1.1 fail. You reached a wrong login page", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                    (Constants.PATH_SCREEN_SHOTS + currentTime)).build());

        login.enterEmail(getData("EMAIL"));   // Read from config.xml file
        login.enterPassword(getData("PASSWORD")); // Read from config.xml file
        login.clickSignInBtn();//Go to LoginPage and click on "SIGN IN".

        //Navigate to Home page, because NEXT blocks the automation entry
        driver.get(getData("NAVIGATE_HOMEPAGE"));
    }

    @Test
        public void b_homePageTest () throws
        InterruptedException, ParserConfigurationException, IOException, SAXException {
            //Clicking on the follow items: garden category,kitchen link banner,hebrew language,search home field.
            //Clicking double click home-button between all of thees items.
            ExtentTest test2 = extentReports.createTest("test2- screen of home page");// title in report
            test2.log(Status.INFO, "Home page");//information that will appear in the detail's column report
            Thread.sleep(1000);
            HomePage home = new HomePage(driver);
            home.doubleClickHomeBanner();
            Thread.sleep(2000);
        System.out.println(driver.getTitle());
            //Verify that you are in the Home page

            try {
                Assert.assertEquals(Constants.HOME_CATEGORY, driver.getTitle());
                test2.pass("Test 2.1 pass. Your are in the right home page!");
            } catch (AssertionError error) {
                test2.fail("Test 2.1 fail. You reached a wrong home page", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                        (Constants.PATH_SCREEN_SHOTS + currentTime)).build());
            }
            // Go to one of the left side categories, for example Garden category

            home.clickGardenLeftLink();
            Thread.sleep(500);

            //Verify that you are in the Garden category in the left bar
            try {
                Assert.assertEquals(Constants.GARDEN_LEFT, driver.getTitle());
                test2.pass("Test 2.2 pass. Your are in the right garden category page!");
            } catch (AssertionError error) {
                test2.fail("Test 2.2 fail. You reached a wrong garden category page", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                        (Constants.PATH_SCREEN_SHOTS + currentTime)).build());
            }

            home.doubleClickHomeBanner();
            Thread.sleep(500);

            //Go to some category from the center of page. It appears circled , for example Kitchen
            home.clickKitchenCategory();
            Thread.sleep(500);
            //Verify that you are in the Kitchen in the center of page
            try {
                Assert.assertEquals(Constants.KITCHEN_CATEGORY, driver.getTitle());
                test2.pass("Test 2.3 pass. Your are in the right kitchen category bar title!");
            } catch (AssertionError error) {
                test2.fail("Test 2.3 fail. You reached a wrong kitchen category bar title", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                        (Constants.PATH_SCREEN_SHOTS + currentTime)).build());
            }
            home.doubleClickHomeBanner();
            Thread.sleep(500);
            home.changeHebrew();
            //search חולצות בנים.Insert this text in the search field
            home.searchProductInHome(getData("SEARH_HOME"));
            Thread.sleep(500);

            //Verify that you are in the categories page
            try {
                Assert.assertEquals(Constants.CATEGORIES, driver.getTitle());
                test2.pass("Test 2.4 pass. Your are in the categories page !");
            } catch (AssertionError error) {
                test2.fail("Test 2.4 fail. You reached a wrong categories page ", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                        (Constants.PATH_SCREEN_SHOTS + currentTime)).build());
            }
            //click the search button to open boys shirt page
            home.searchProductInHomeBtn();

            //Verify that you are in the Boy's shirts page
            try {
                Assert.assertEquals(Constants.BOYS_SHIRTS, driver.getTitle());
                test2.pass("Test 2.5 pass. Your are in the right boy's shirts page !");
            } catch (AssertionError error) {
                test2.fail("Test 2.5 fail. You reached a wrong boy's shirts page ", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                        (Constants.PATH_SCREEN_SHOTS + currentTime)).build());
            }
        }

    @Test
    public void c_boysShirtsPage() throws InterruptedException, ParserConfigurationException, IOException, SAXException {
        //להוריד את שורת הget לפני הגשת הפרויקט
        driver.get("https://www.next.co.il/he/g884704s1/966151#966151");
        ExtentTest test3 = extentReports.createTest("test3- screen of boys shorts page");// title in report
        test3.log(Status.INFO, "Boys shirts page");//information that will appear in the detail's column report

        //Verify that you are in some model shirt page, before you chose color and size
        try {
            Assert.assertEquals(Constants.SHIRT_MODEL, driver.getTitle());
            test3.pass("Test 3.1 pass. Your are in the some shirt page!");
        } catch (AssertionError error) {
            test3.fail("Test 3.1 fail. You reached a wrong some shirt page", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                    (Constants.PATH_SCREEN_SHOTS + currentTime)).build());
        }
        Thread.sleep(1000);
        BoysShirtsPage shirts=new BoysShirtsPage(driver);
        Thread.sleep(1000);

        //Choose first shirt- click on the picture חולצת פולו חלקה עם שרווחל קצר(3חודשים עד גיל 7)
        shirts.selectShirt();

       //Choose color of box
        shirts.colorBoxClick();
        Thread.sleep(2000);
        //Choose color of box
        shirts.sizeBoxClick();
        Thread.sleep(2000);
        //Add to basket
        shirts.addToBasketClick();
        Thread.sleep(3000);

        //add another shirt to the basket - the same color, but different size
        shirts.anotherSize();
        shirts.addToBasketClick();
        Thread.sleep(3000);
        //check the basket
        shirts.editBasketClick();

        //Verify that you are in the shopping bag page
        try {
            Assert.assertEquals(Constants.SHOPPING_BAG, driver.getTitle());
            test3.pass("Test 3.2 pass. Your are in the shopping bag page!");
        } catch (AssertionError error) {
            test3.fail("Test 3.2 fail. You reached a wrong shopping  page title", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                    (Constants.PATH_SCREEN_SHOTS + currentTime)).build());
        }
        Thread.sleep(3000);
        shirts.cashRegisterClick();

        //Verify that you are in the login page
        try {
            Assert.assertEquals(Constants.ANOTHER_LOGIN, driver.getTitle());
            test3.pass("Test 3.3 pass. Your are in the login page!");
        } catch (AssertionError error) {
            test3.fail("Test 3.3 fail. You reached a wrong login  page", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                    (Constants.PATH_SCREEN_SHOTS + currentTime)).build());
        }

        Thread.sleep(3000);
         }
         // The follow test is declare as Ignore.It can't be run, because NEXT site blocks
         // automation to insert credit data.
    @Ignore
    public  void d_paymentPage() throws InterruptedException, ParserConfigurationException, IOException, SAXException {
        ExtentTest test4 = extentReports.createTest("test4- screen of payment page");// title in report
        test4.log(Status.INFO, "Payment page");//information that will appear in the detail's column report
        Thread.sleep(1000);
        PaymentPage payment= new PaymentPage(driver);
        ExtentTest lastTest= extentReports.createTest("last test");
        Thread.sleep(3000);

        //insert payment details from config.xml file
        payment.enterEmail(getData("EMAIL"));
        payment.enterPassword(getData("PASSWORD"));
        payment.signInClick();
        System.out.println("payment page+ "+driver.getTitle());
        //Verify that you are in the login page
        try {
            Assert.assertEquals(Constants.PAYMENT_PAGE, driver.getTitle());
            test4.pass("Test 3.4 pass. Your are in the payment page!");
        } catch (AssertionError error) {
            test4.fail("Test 3.4 fail. You reached a wrong payment  page", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                    (Constants.PATH_SCREEN_SHOTS + currentTime)).build());
        }
        payment.creditCardOrDirectClick();
        payment.enterCarNumber(getData("CARD_NUMBER"));
        payment.enterMonthExpiry(getData("MONTH"));
        payment.enterMonthExpiry(getData("YEAR"));
        payment.enterCodeExpiry(getData("CODE"));
        payment.payNowClick();

        String currentTime12 = String.valueOf(System.currentTimeMillis());
        lastTest.pass("Entering Visa card details", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                (Constants.PATH_SCREEN_SHOTS + currentTime12)).build());

        //Verify that you get message "Insert right card number"
        ExtentTest test13 = extentReports.createTest("test12");
        String cardNumberMessage = payment.txtMessageWrongCreditCard();
        if (cardNumberMessage.equals(Constants.CARD_NUMBER_MSG)){
            String currentTime13 = String.valueOf(System.currentTimeMillis());
            test13.pass("Make sure that you get message \"Insert right card number", MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot
                    ("target\\Spark" + currentTime13)).build());
        }
    }
    @AfterClass
    public static void afterclass() throws InterruptedException, IOException {
        System.out.println("after class");
        Thread.sleep(5000);
        driver.quit();
        extentReports.flush();// write to report. Without this row the index.html will not be created

    }
    //getData- config.xml file needs it
    private static String getData (String keyName) throws ParserConfigurationException, IOException, SAXException {
        File configXmlFile = new File(Constants.XML_LOCATION);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = null;

        dBuilder = dbFactory.newDocumentBuilder();

        Document doc = null;

        assert dBuilder != null;
        doc = dBuilder.parse(configXmlFile);

        if (doc != null) {
            doc.getDocumentElement().normalize();
        }
        assert doc != null;
        return doc.getElementsByTagName(keyName).item(0).getTextContent();
    }
    //screen shot needs it
    private static String takeScreenShot(String ImagesPath) {
        TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
        File screenShotFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
        File destinationFile = new File(ImagesPath+".png");
        try {
            FileUtils.copyFile(screenShotFile, destinationFile);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return ImagesPath+".png";
    }
}
