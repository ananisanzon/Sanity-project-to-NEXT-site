package pages;

public class Constants {
    public final static String CHROME_DRIVER_LOCATION="C:\\Users\\User\\Desktop\\Winnerit\\chromedriver113.exe";
    public final static String SITE_PATH="https://www.next.co.il/he/shop/department-homeware-productaffiliation-childrensbedroom/category-bedsets";
    public final static String XML_LOCATION="C:\\Users\\User\\Desktop\\Winnerit\\NextSanity\\target\\config.xml";
    public final static String PATH_REPORTS="target/spark/index.html";
    public final static String PATH_SCREEN_SHOTS= "target\\spark\\pictures";
    public final static String TITLE_LOGIN="Sign In | My Account | Next Directory Online11";
    public final static String HOME_CATEGORY= "Furniture & Homeware | Next Home & Garden | Next UK";
                                           //Furniture & Homeware | Next Home & Garden | Next UK
    public final static String GARDEN_LEFT= "Garden & Outdoors | Garden Furniture Sets & Accessories | Next";
    public final static String KITCHEN_CATEGORY= "Kitchenware | Kitchen Accessories & Essentials | Next Israel";
    //in this page "CATEGORIES" we insert searh test- חולצות בנים
    public final static String CATEGORIES="האתר הרשמי של Next: אופנה, בגדי ילדים ועיצוב הבית אונליין";
    public final static String BOYS_SHIRTS="Tops younger boys from | נקסט ישראל";
    public final static String SHIRT_MODEL="קנה חולצת פולו לבנה חלקה עם שרוול קצר עם אמרה (3 חודשים עד גיל 7) מנקסט ישראל";
    public final static String SHOPPING_BAG="Next Israel";
    public final static String ANOTHER_LOGIN="התחבר | החשבון שלי | קטלוג נקסט באינטרנט";
    public final static String PAYMENT_PAGE="ההזמנות שלי | החשבון שלי | קטלוג נקסט באינטרנט";
    public final static String CARD_NUMBER_MSG= "הזן מספר כרטיס תקין";
    public final static String TITLE_HOME_RIGHT="Tops younger boys from | נקסט ישראל";
}
