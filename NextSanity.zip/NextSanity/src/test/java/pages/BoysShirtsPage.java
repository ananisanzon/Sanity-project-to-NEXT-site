package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BoysShirtsPage {
    //declare driver
    WebDriver driver;

    //declare locators
    private By myShirt= By.xpath("//*[@id=\"platform_modernisation_product_summary_966151\"]/div/div[1]/div[1]/div/div/div[1]/a/img");
    private By colorCheckBox= By.cssSelector("[id*='dk_container_Colour-']");
    //green-menta color
    private By spesificColor= By.xpath ( "//*[@id=\"dk_container_Colour-797345\"]/div/ul/li[4]/a");
    private By sizeCheckBox= By.xpath("//*[@id=\"dk_container_Size-U66-708\"]");
    //size 6-9 month
    private By spesificSize= By.xpath("//*[@id=\"dk_container_Size-U66-708\"]/div/ul/li[3]/a");
    //size 2-3 years
    private By anotherSize= By.xpath("//*[@id=\"dk_container_Size-U66-708\"]/div/ul/li[7]/a");
    private By addToBasketBtn= By.xpath("//*[@id=\"Style797345\"]/section/div[4]/div[5]/div[4]/div/a[1]");
    private By editBasketBtn= By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[7]/div[2]/div/div/div[2]/div/div/div[3]/div[1]/a");
    private By cashRegesterBtn= By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[8]/div/a");


    //constructor
    public BoysShirtsPage(WebDriver driver){
        this.driver=driver;
    }
    //methods
    //first shirt- click on the picture חולצת פולו חלקה עם שרווחל קצר(3חודשים עד גיל 7)
    public void selectShirt(){
        driver.findElement(myShirt).click();
    }
    public void colorBoxClick(){
        driver.findElement(colorCheckBox).click();
        driver.findElement(spesificColor).click();
    }
    public void sizeBoxClick() {
        driver.findElement(sizeCheckBox).click();
        driver.findElement(spesificSize).click();
    }
    public void addToBasketClick(){
        driver.findElement(addToBasketBtn).click();
    }
    public void anotherSize(){
        driver.findElement(sizeCheckBox).click();
        driver.findElement(anotherSize).click();
    }
    public void editBasketClick(){
        driver.findElement(editBasketBtn).click();
    }
    public void cashRegisterClick(){
        driver.findElement(cashRegesterBtn).click();
    }
}
