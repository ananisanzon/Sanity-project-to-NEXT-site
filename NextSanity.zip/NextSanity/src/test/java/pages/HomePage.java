package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class HomePage {
    //declare driver
    WebDriver driver;

    //declare locators
    private By homeBanner= By.xpath("//*[@id=\"meganav-link-6\"]/div");
    private By gardenLeftLink= By.xpath("//*[@id=\"left-sidebar-links7-4zmjac3wfm4z0b9vqagy84ujo\"]");
    private By kitchenCategory= By.xpath("//*[@id=\"buttonlist1\"]/div/div[2]/div/div/div[6]/a");
    private By language= By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[9]/button/img");
    private By hebrew= By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[10]/div/div[3]/div/div[4]/div/button[1]");
    //click shopNowBtn to change a language
    private By shopNowBtn= By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[10]/div/div[3]/div/div[5]/button");
    private By searchHomeText= By.xpath("//*[@id=\"header-big-screen-search-box\"]");
    private By searchHomeBtn=By.xpath("//*[@id=\"header-search-form\"]/button/img");

    //constructor
    public HomePage(WebDriver driver){
        this.driver=driver;
    }
    //methods
    public void doubleClickHomeBanner(){
        WebElement elementDoubleClick=driver.findElement(homeBanner);//Element that I want  double click him
        Actions actions= new Actions(driver);//Declare Mofa actions in order to use double click
        actions.doubleClick(elementDoubleClick);//Actions function do doubleClick, send to the function element to doubleClick it
        actions.build().perform();//actually do 2 things: send 2 clicks and perform 2 clicks
    }
    public void clickGardenLeftLink(){
        driver.findElement(gardenLeftLink).click();
    }
    public void clickKitchenCategory(){
        driver.findElement(kitchenCategory).click();
    }

    //Change a language in the site
    public void changeHebrew() throws InterruptedException {
        driver.findElement(language).click();
        Thread.sleep(1000);
        driver.findElement(hebrew).click();
        Thread.sleep(1000);
        driver.findElement(shopNowBtn).click();//actually change a language
    }
    //Insert text "חולצות בנים" in the search textbox
    public void searchProductInHome(String search){
        driver.findElement(searchHomeText).sendKeys(search);
    }
    //Open the "חולצות בנים" page
    public void searchProductInHomeBtn(){
        driver.findElement(searchHomeBtn).click();
    }
}
