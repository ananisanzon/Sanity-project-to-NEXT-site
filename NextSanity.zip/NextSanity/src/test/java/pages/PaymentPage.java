package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PaymentPage {
    //declare driver
    WebDriver driver;
    //declare locators
    private By userMail= By.xpath("//*[@id=\"EmailOrAccountNumber\"]");
    private By userPassword=By.xpath("//*[@id=\"Password\"]");
    private By signInNow= By.id("SignInNow");
    private By methodOfPayment= By.xpath("//*[@id=\"PaymentId\"]");
    private By cardNumber = By.id("cardNumber");
    private By monthExpiry= By.xpath("//*[@id=\"expiryMonth\"]");
    private By yearExpiry=By.xpath("//*[@id=\"expiryYear\"]");
    private By codeSecurity= By.id("securityCode");
    private By payNowBtn= By.xpath("//*[@id=\"submitButton\"]");
    private By msgWrongCreditCard= By.xpath("//*[@id=\"ct\"]/div[4]/form/div[1]/div[1]/div/div");

    //constructor
    public PaymentPage(WebDriver driver){
        this.driver=driver;
    }
    //methods
    public void enterEmail(String email){
        driver.findElement(userMail).sendKeys(email);
    }
    public void enterPassword(String password){
        driver.findElement(userPassword).sendKeys(password);
    }
    public void signInClick(){
        driver.findElement(signInNow).click();
    }
    public void creditCardOrDirectClick() throws InterruptedException {
        Thread.sleep(3000);
        driver.findElement(methodOfPayment).click();
    }
    public void enterCarNumber(String cardNum){
        driver.findElement(cardNumber).sendKeys(cardNum);
    }
    public void enterMonthExpiry(String month){
        driver.findElement(monthExpiry).sendKeys(month);
    }
    public void enterYearExpiry(String year){
        driver.findElement(yearExpiry).sendKeys(year);
    }
    public void enterCodeExpiry(String code){
        driver.findElement(codeSecurity).sendKeys(code);
    }
    public void payNowClick(){
        driver.findElement(payNowBtn).click();
    }
    //text of message that say about wrong number of credit card
    public String txtMessageWrongCreditCard(){
        driver.findElement(msgWrongCreditCard).getText();
        return null;
    }
}
