package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    WebDriver driver; //declare driver

    //declare locators
    private  By acountLinkLocator=By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[4]/div[2]/div/a/img");

    private By emailLocator= By.id("EmailOrAccountNumber");
    private By passwordLocator= By.id("Password");
    private By signIn= By.xpath("//*[@id=\"SignInNow\"]");

    //constructor
    public LoginPage(WebDriver driver) //הקונסטרקטור מקבל כאן את הdriver  מהSanityTest
    {
        this.driver = driver;
    }
    //methods
    public void clickAccountBtn(){
        driver.findElement(acountLinkLocator).click();
    }
    public void enterEmail(String email){
        driver.findElement(emailLocator).sendKeys(email);
    }
    public void enterPassword(String password) {
        driver.findElement(passwordLocator).sendKeys(password);
    }
    public void clickSignInBtn(){
        driver.findElement(signIn).click();
    }
}
