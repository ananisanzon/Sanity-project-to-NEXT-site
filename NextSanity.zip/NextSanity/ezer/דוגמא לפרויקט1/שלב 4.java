package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class ProductPage {
    //set up driver
    private static WebDriver driver;

    //locators on page
    private By dropDownColourLocator = By.xpath("//*[@id=\"dk_container_Colour-915273\"]/a");
    private By colourRainbowLocator = By.linkText("קשת");
    private By dropDownSizeLocator = By.xpath("//*[@id=\"dk_container_Size-C81-533\"]/a");
    private By sizeSixToNineMonthLocator = By.partialLinkText("מידה אירופית 68-74ס״מ");
    private By sizeFourToFiveYearsLocator = By.partialLinkText("מידה אירופית 104-110ס״מ");
    private By addToBagLocator = By.linkText("הוסף לסל");
    private By bagBtnLocator = By.xpath("//*[@id=\"platform_modernisation_header\"]/header/div[1]/nav/div[7]/div[2]/div[1]/a/div");
    private By viewOrEditBagBtnLocator = By.linkText("הצג/ערוך סל");
    private By checkoutBtnLocator = By.linkText("לקופה");

    //constructor
    public ProductPage(WebDriver driver){
        this.driver = driver;
    }

    //functions
    public void clickDropDownColour(){
        driver.findElement(dropDownColourLocator).click();
    }
    public void chooseRainbowColour(){
        driver.findElement(colourRainbowLocator).click();
    }
    public void clickDropDownSize(){
        driver.findElement(dropDownSizeLocator).click();
    }
    public void chooseSizeSixToNineMonths(){
        driver.findElement(sizeSixToNineMonthLocator).click();
    }
    public void chooseSizeFourToFiveYears(){
        driver.findElement(sizeFourToFiveYearsLocator).click();
    }
    public void clickAddToBag(){
        driver.findElement(addToBagLocator).click();
    }
    public void clickBag(){
        driver.findElement(bagBtnLocator).click();
    }
    public void clickShowOrEditBtn(){
        driver.findElement(viewOrEditBagBtnLocator).click();
    }
    public void clickCheckoutBtn(){
        driver.findElement(checkoutBtnLocator).click();
    }
    public String getSelectedColour(){
      return driver.findElement(dropDownColourLocator).getText();
    }
    public String getSelectedSize(){
       return driver.findElement(dropDownSizeLocator).getText();
    }



}
