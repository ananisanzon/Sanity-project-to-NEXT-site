package testcases;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.apache.commons.io.FileUtils;
import org.checkerframework.checker.units.qual.A;
import org.junit.*;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import pages.*;
import javax.xml.parsers.*;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
//Run tests in ascending order
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class SanityTest {
    private static WebDriver driver;
    private static ExtentReports extentReports = new ExtentReports();
    private static ExtentSparkReporter reporter = new ExtentSparkReporter(Constants.REPORT_LOCATION);
    String currentTime = String.valueOf(System.currentTimeMillis());

    HomePage homePage = new HomePage(driver);
    SignInPage signIn = new SignInPage(driver);
    HomeCategoryPage homeCategory = new HomeCategoryPage(driver);
    BabyCategoryPage babyCategory = new BabyCategoryPage(driver);
    GirlsDressesPage girlsDresses = new GirlsDressesPage(driver);
    ProductPage productPage = new ProductPage(driver);
    PaymentPage paymentPage = new PaymentPage(driver);


    @BeforeClass
    public static void beforeClass() throws ParserConfigurationException, IOException, SAXException {
        System.out.println("before class");
        extentReports.attachReporter(reporter);
        System.setProperty("webdriver.chrome.driver",Constants.CHROMEDRIVER_LOCATION);
        ChromeOptions options = new ChromeOptions();
        options.addArguments("-incognito");
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(getDataItem("Url",0));
    }



    @Test
    public void A_signInTest() throws ParserConfigurationException, IOException, SAXException{
        System.out.println("Sign in Test");
        ExtentTest signInTest = extentReports.createTest("signInTest");

        //click to sign in and verification
        homePage.clickMyAccount();
        waiting();
        try {
            Assert.assertEquals(Constants.SIGN_IN_PAGE_TITLE, driver.getTitle());
            signInTest.pass("Step 1 passed - You reached the Sign in page");
        }
        catch(AssertionError error){
            signInTest.fail("Step 1 failed - There was an error reaching the Sign in page",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+" signInTestStep1")).build());
        }

        //sign in with existing account
        signIn.enterEmailAddress(getDataItem("Email",0));
        waiting();
        signIn.enterPassword(getDataItem("Password",0));
        waiting();
        signIn.clickSignInBtn();
        waiting();

        //verification that sign in was successful(reached order tracking page)
        //Assert.assertEquals(Constants.MY_ACCOUNT_ORDER_TRACKING_TITLE,driver.getTitle());
        //the website realized it's automation so i'm navigating back to homepage
        driver.navigate().to(getDataItem("Url",0));
        try {
            Assert.assertEquals(Constants.HOMEPAGE_TITLE,driver.getTitle());
            signInTest.pass("Step 2 passed - Sign in was successful");
        }
        catch(AssertionError error){
            signInTest.fail("Step 2 failed - Sign in failed",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+" signInTestStep2")).build());
        }

    }

    @Test
    public void B_homeCategoryTest() throws IOException {
        System.out.println("Home Category Test");
        ExtentTest chooseCategoriesTest = extentReports.createTest("Home Category Test");

        //go into a link (home category) on the banner + verification
        homePage.doubleClickHomeCategory();
        waiting();
        try {
            Assert.assertEquals(Constants.HOME_CATEGORY_PAGE_TITLE,driver.getTitle());
            chooseCategoriesTest.pass("Step 1 passed - You reached the home page category through the link on the banner ");
        }
        catch(AssertionError error){
            chooseCategoriesTest.fail("Step 1 failed - There was a problem reaching the page through the link on the banner",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+ " homeCategoryTestStep1")).build());
        }

       //go into one of the links on the left side + verification
       homeCategory.clickSubCategoryNewInHomewareLink();
       waiting();
       try {
            Assert.assertEquals(Constants.SUB_CATEGORY_NEW_IN_HOMEWARE_PAGE_TITLE,driver.getTitle());
            chooseCategoriesTest.pass("Step 2 passed - You successfully entered the New In Homeware page through the link on the left side");
       }
       catch(AssertionError error){
            chooseCategoriesTest.fail("Step 2 failed - There was a problem reaching the New In Homeware page through the link on the left side",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+" homeCategoryTestStep2")).build());
       }

       //return to homepage Home Category and go into one of the categories from the center of page + verification
       homeCategory.returnToTheHomeShopPage();
       waiting();
       homeCategory.clickSubCategoryBedroom();
       waiting();
       try {
            Assert.assertEquals(Constants.SUB_CATEGORY_BEDROOM_PAGE_TITLE,driver.getTitle());
            chooseCategoriesTest.pass("Step 3 passed - You successfully entered the Bedroom Category page through the categories from the center of the page");
       }
       catch(AssertionError error){
            chooseCategoriesTest.fail("Step 3 failed - There was a problem reaching the Bedroom Category page through the categories from the center of the page",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+" homeCategoryTestStep3")).build());
       }

        //return to homepage + verification
        homePage.clickNextIconHeader();
        waiting();
        try {
            Assert.assertEquals(Constants.HOMEPAGE_TITLE,driver.getTitle());
            chooseCategoriesTest.pass("Step 4 passed - You successfully returned to the Homepage");
        }
        catch(AssertionError error){
            chooseCategoriesTest.fail("step 4 failed - There was a problem returning to the Homepage",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+" homeCategoryTestStep4")).build());
        }

    }

    @Test
    public void C_babyCategoryTest() throws ParserConfigurationException, IOException, SAXException {
       System.out.println("Baby Category Test");
       ExtentTest chooseCategoriesTest = extentReports.createTest("Baby Category Test");

       //go into a link (baby category) on the banner + verification
       homePage.doubleClickBabyCategory();
       waiting();
       try {
            Assert.assertEquals(Constants.BABY_CATEGORY_PAGE_TITLE,driver.getTitle());
            chooseCategoriesTest.pass("Step 1  passed - You reached the Baby Category through the link on the banner");
       }
       catch(AssertionError error){
            chooseCategoriesTest.fail("Step 1  failed - There was a problem reaching the page through the link on the banner",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime + " babyCategoryTestStep1")).build());
       }

       //go into one of the links on the left side + verification
       babyCategory.clickNewBornClothingLink();
       waiting();
       try {
            Assert.assertEquals(Constants.SUB_CATEGORY_NEWBORN_CLOTHING_PAGE_TITLE,driver.getTitle());
            chooseCategoriesTest.pass("Step 2 passed - You successfully entered the Newborn Clothing page through the link on the left side");
       }
       catch(AssertionError error){
            chooseCategoriesTest.fail("Step 2 failed - There was a problem reaching the Newborn Clothing page through the link on the left side",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+ " babyCategoryTestStep2")).build());
       }

       //return to homepage baby category and go into a category (sleep) from the center of page + verification
       babyCategory.returnToBabyShopPage();
       waiting();
       babyCategory.clickSleepCategory();
       waiting();
        try {
            Assert.assertEquals(Constants.SUB_CATEGORY_SLEEP_PAGE_TITLE,driver.getTitle());
            chooseCategoriesTest.pass("Step 3 passed - You successfully entered the Sleep Category page through the categories from the center of the page");
        }
        catch(AssertionError error){
            chooseCategoriesTest.fail("Step 3 failed - There was a problem reaching the Sleep Category page through the categories from the center of the page",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+ " babyCategoryTestStep3")).build());
        }

       //return to homepage + verification
       homePage.clickNextIconHeader();
       waiting();
        try {
            Assert.assertEquals(Constants.HOMEPAGE_TITLE,driver.getTitle());
            chooseCategoriesTest.pass("Step 4 passed - You successfully returned to the Homepage");
        }
        catch(AssertionError error){
            chooseCategoriesTest.fail("Step 4 failed - There was a problem returning to the Homepage",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+ " babyCategoryTestStep4")).build());
        }
    }

    @Test
    public void D_changeLanguageToHebrewTest() throws ParserConfigurationException, IOException, SAXException {
        System.out.println("Change language Test");
        ExtentTest changeLanguageTest = extentReports.createTest("Change Language Test");

        //change language of website to hebrew
        homePage.clickCountryAndLanguageBtn();
        waiting();
        homePage.clickHebrewLanguageBtn();
        waiting();
        homePage.clickShopNowBtn();
        waiting();
        //verification
        try {
            Assert.assertEquals(getDataItem("Url",1), driver.getCurrentUrl());
            changeLanguageTest.pass("The website has successfully changed to hebrew");
        }
        catch(AssertionError error){
            changeLanguageTest.fail("changeLanguageToHebrewTest has failed",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime + " changeLanguageTest")).build());
        }
    }

    @Test
    public void E_searchTest() throws ParserConfigurationException, IOException, SAXException {
        System.out.println("Search Test");
        ExtentTest searchTest = extentReports.createTest("search Test");
        //search for dress in search box
        /*homePage.clickAndEnterDataSearchBox("dress");
        waiting();*/
        //doesn't work with Nativ filter so I navigated to a certain url
        driver.navigate().to(getDataItem("Url",2));
        waiting();
        try {
            Assert.assertEquals(Constants.GIRLSDRESSES_PAGE_TITLE,driver.getTitle());
            searchTest.pass("Step 1 passed - You successfully reached the girls dresses page");
        }
        catch(AssertionError error){
            searchTest.fail("Step 1 failed - There was a problem reaching the girls dresses page",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+ " searchTestStep1")).build());
        }

        //choose first item
        girlsDresses.clickFirstDress();
        waiting();
        try {
            Assert.assertEquals(Constants.PRODUCT_PAGE_TITLE,driver.getTitle());
            searchTest.pass("Step 2 passed - You successfully reached the product page");
        }
        catch(AssertionError error){
            searchTest.fail("Step 2 failed - There was a problem reaching the product page",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime + " searchTestStep2")).build());
        }
    }

    @Test
    public void F_productPageTest() throws IOException {
       System.out.println("Product page test");
       ExtentTest productPageTest = extentReports.createTest("Product Page Test");

       //choose colour
       productPage.clickDropDownColour();
       waiting();
       productPage.chooseRainbowColour();
       waiting();
       //verification colour
        String expectedColour = "קשת";
        try {
            Assert.assertEquals(expectedColour, productPage.getSelectedColour());
            productPageTest.pass("Step 1 passed - The colour קשת has been selected");
        }
        catch(AssertionError error){
            productPageTest.fail("Step 1 failed - There was a problem selecting the colour קשת",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+" productPageTestStep1")).build());
        }

       //choose size + verification + add to bag
       productPage.clickDropDownSize();
       waiting();
       productPage.chooseSizeSixToNineMonths();
       waiting();
       //verification size
       String expectedSize = "6-9 חודשים (UK ) (מידה אירופית 68-74ס״מ) - 42 ₪";
       try{
           Assert.assertEquals(expectedSize,productPage.getSelectedSize());
           productPageTest.pass("Step 2 passed - The size 6-9 months has been selected");
       }
       catch(AssertionError error){
           productPageTest.fail("Step 2 failed - There was a problem selecting the size 6-9 months",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+"productPageTestStep2")).build());
       }
       productPage.clickAddToBag();
       waiting();

       //choose another size
        productPage.clickDropDownSize();
        waiting();
        productPage.chooseSizeFourToFiveYears();
        waiting();
        //verification size + add to bag
        String expectedSize2 = "4-5 שנים (UK ) (מידה אירופית 104-110ס״מ) - 46 ₪";
        try{
            Assert.assertEquals(expectedSize2,productPage.getSelectedSize());
            productPageTest.pass("Step 3 passed - The size 4-5 years has been selected");
        }
        catch(AssertionError error){
            productPageTest.fail("Step 3 failed - There was a problem selecting the size 4-5 years",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+"productPageTestStep3")).build());
        }
        productPage.clickAddToBag();
        waiting();

        //check your bag and go to checkout
        productPage.clickBag();
        waiting();
        productPage.clickCheckoutBtn();
        waiting();
        //verification
        try{
            Assert.assertEquals(Constants.PAYMENT_PAGE_TITLE,driver.getTitle());
            productPageTest.pass("Step 4 passed - You successfully reached the Payment Page");
        }
        catch(AssertionError error){
            productPageTest.fail("Step 4 failed - There was a problem reaching the Payment Page",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+"productPageTestStep4")).build());
        }
    }

    @Ignore
    @Test
    public void G_paymentTest() throws ParserConfigurationException, IOException, SAXException {
        System.out.println("Payment Test");
        ExtentTest paymentTest = extentReports.createTest("Payment Test");

        //choose to pay by credit card
        paymentPage.clickCardPaymentMethod();
        //verification
        if(paymentPage.isSelectedCardPaymentMethod())
            paymentTest.pass("Step 1 passed - Card option is selected");
        else
            paymentTest.fail("Step 1 failed - There was a problem selecting the card option",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+"paymentTestStep1")).build());

        //enter payment details and pay
        paymentPage.enterCardNumber(getDataItem("CardNumber",0));
        paymentPage.enterExpiryMonth(getDataItem("ExpiryMonth",0));
        paymentPage.enterExpiryYear(getDataItem("ExpiryYear",0));
        paymentPage.enterSecurityCode(getDataItem("SecurityCode",0));
        paymentPage.clickPayNow();
        //verification error message displayed
        String expectedCardErrorMessage = "הזן מספר כרטיס תקין";
        try{
            Assert.assertEquals(expectedCardErrorMessage,paymentPage.getCardErrorMessage());
            paymentTest.pass("Step 2 passed - Card error message displayed");
        }
        catch(AssertionError error){
            paymentTest.fail("Step 2 failed - Card error message is not displayed",MediaEntityBuilder.createScreenCaptureFromPath(takeScreenShot("C:\\Users\\course automation\\ProjectSeleniumNextSite\\target\\screenshots\\"+ currentTime+"paymentTestStep2")).build());

        }
    }

    @AfterClass
    public static void afterClass(){
        driver.quit();
        extentReports.flush();
    }

    //functions
    public static void waiting(){
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static String getDataItem (String keyName, int index) throws ParserConfigurationException, IOException, SAXException, SAXException, SAXException, ParserConfigurationException, IOException, SAXException {
        File configXmlFile = new File(Constants.XML_LOCATION);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = null;

        dBuilder = dbFactory.newDocumentBuilder();

        Document doc = null;

        assert dBuilder != null;
        doc = dBuilder.parse(configXmlFile);

        if (doc != null) {
            doc.getDocumentElement().normalize();
        }
        assert doc != null;
        return doc.getElementsByTagName(keyName).item(index).getTextContent();
    }

    private static String takeScreenShot(String ImagesPath) {
        TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
        File screenShotFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
        File destinationFile = new File(ImagesPath+".png");
        try {
            FileUtils.copyFile(screenShotFile, destinationFile);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return ImagesPath+".png";
    }

}
